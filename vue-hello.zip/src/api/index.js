/**
 * 自动引入当前文件夹下所有module
 * require.context(directory, useSubdirectories = false, regExp = /^.//);
 * @param {String} directory 读取文件的路径
 * @param {Boolean} directory 匹配文件的正则表达式
 * @param {regExp} regExp 读取文件的路径
 */

let api = {}

const modulesFiles = require.context('./modules', true, /.js$/)
modulesFiles.keys().reduce((modules, modulePath) => {
    const moduleName = `$_${modulePath.replace(/^.\/(.*)\.js/, '$1')}`
    const value = modulesFiles(modulePath)
    api[moduleName] = value.default
}, {})


api.install = Vue => {
    for (let i in api) {
        Vue.prototype[`${i}`] = api[i]
    }
}
export default api
