import request from '@/utils/request'
export default {
    getObsInfo: query => {
        return request({
            url: `/api/obsInfo`,
            method: 'get',
            params: query,
        })
    },
   
}
