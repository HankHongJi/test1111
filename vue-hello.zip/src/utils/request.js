import axios from 'axios'
import { MessageBox, Notification } from 'element-ui'
import httpStatus from './httpStatus'
const service = axios.create({
    // baseURL: 'https://www.easy-mock.com/mock/36/',
    timeout: 10000,
})

service.interceptors.request.use(
    // noError => 是否支持报错
    // loading => 是否支持加载状态
    // setLoading => 加载状态回调
    config => {
        config.loading && loadingService.setLoading()
        setLoadingFn(config, true)
        if (config.params && config.params.page) {
            config.params = Object.assign({}, config.params, { page: config.params.page - 1 })
        }
        return config
    },
    error => {
        return Promise.reject()
    },
)

service.interceptors.response.use(
    response => {
        loadingService.finishLoading()
        setLoadingFn(response.config, false)
        if (response.status >= 200 && response.status < 300) {
            let { config, headers, data } = response
            // 处理翻页total
            let total = headers['x-total-count']
            if (total) {
                return {
                    total: total - 0,
                    rows: data,
                }
            } else {
                return data
            }
        } else {
            Promise.reject()
        }
    },
    error => {
        loadingService.finishLoading()
        let response = error.response
        if (!response) {
            // MessageBox({ title: '提示', message: error.message })
            return Promise.reject()
        }
        let { status, config, headers, data } = response
        data._status = status
        setLoadingFn(config, false)
        switch (status) {
            case 401:
                // data.detail = '用户验证不通过，请重新登录'
                // data.title = ''
                $alert(config, data, () => {
                    !location.hash.includes('login') && location.reload()
                })
                localStorage.removeItem('user_data')
                break
            default:
                $alert(config, data)
                break
        }
        return Promise.reject()
    },
)

export default service
