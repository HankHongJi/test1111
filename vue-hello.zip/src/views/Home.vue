<template>
    <div class="home">
        <div id="app">
            <div data-v-6888da47="" class="account_content">
                <div data-v-6888da47="" class="accountList_content">
                    <div class="accountList_swiper">
                        <ul>
                            <li
                                class="accountItem1 swiper-button-disabled"
                                tabindex="0"
                                role="button"
                                aria-label="Previous slide"
                                aria-disabled="true"
                            >
                                <p class="active">公积金账户</p>
                            </li>
                        </ul>
                    </div>
                    <div
                        class="swiper-container swiper-container-initialized swiper-container-horizontal"
                    >
                        <div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px);">
                            <div class="swiper-slide swiper_left swiper-slide-active">
                                <div class="account_item">
                                    <img src="../assets/accountbg1.png">
                                    <span class="account_detail">账户明细</span>
                                    <div class="account_con">
                                        <p>个人账户余额</p>
                                        <div class="account_left">
                                            <span>29005.37</span>
                                            <img src="../assets/eyeopen.png">
                                        </div>
                                        <div class="account_status">
                                            <span>账户状态：</span>
                                            <span>正常</span>
                                        </div>
                                        <div class="account_bottom" style="margin-left: 21.375px;">
                                            <ul>
                                                <li>
                                                    <p>我的缴存</p>
                                                    <p>
                                                        <span>1248</span>
                                                        <span>.</span>
                                                    </p>
                                                    <p>最近缴存：202004</p>
                                                </li>
                                                <li>
                                                    <p>我的提取</p>
                                                    <p>
                                                        <span>173500</span>
                                                        <span>.</span>
                                                    </p>
                                                    <p>最近提取：201808</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <!---->
                                </div>
                                <div data-v-ffe54062="" class="line_item">
                                    <ul data-v-ffe54062="">
                                        <li data-v-ffe54062="">
                                            <span data-v-ffe54062="">个人姓名</span>
                                            <span data-v-ffe54062="">**腾</span>
                                        </li>
                                        <li data-v-ffe54062="">
                                            <span data-v-ffe54062="">单位账号</span>
                                            <span data-v-ffe54062="">20100001041</span>
                                        </li>
                                        <li data-v-ffe54062="">
                                            <span data-v-ffe54062="">个人账号</span>
                                            <span data-v-ffe54062="">200333605</span>
                                        </li>
                                        <li data-v-ffe54062="">
                                            <span data-v-ffe54062="">账户状态</span>
                                            <span data-v-ffe54062="">正常</span>
                                        </li>
                                        <li data-v-ffe54062="">
                                            <span data-v-ffe54062="">缴存基数</span>
                                            <span data-v-ffe54062="">5197</span>
                                        </li>
                                        <li data-v-ffe54062="">
                                            <span data-v-ffe54062="">个人比例</span>
                                            <span data-v-ffe54062="">12</span>
                                        </li>
                                        <li data-v-ffe54062="">
                                            <span data-v-ffe54062="">月缴存额</span>
                                            <span data-v-ffe54062="">1248</span>
                                        </li>
                                        <li data-v-ffe54062="">
                                            <span data-v-ffe54062="">公积金余额</span>
                                            <span data-v-ffe54062="">29005.37</span>
                                        </li>
                                        <li data-v-ffe54062="">
                                            <span data-v-ffe54062="">工作单位</span>
                                            <span data-v-ffe54062="">安徽神源煤化工有限公司</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  }
}
</script>
