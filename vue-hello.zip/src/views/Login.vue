<template>
    <div class="home">
        <div data-v-0f480a62="" class="login_content">
            <div data-v-0f480a62="" class="login_title">
                <h6 data-v-0f480a62="">登录</h6>
            </div>
            <!-- <span data-v-0f480a62="" class="close"></span> -->
            <img data-v-0f480a62="" src="../assets/login.png">
            <div data-v-0f480a62="" class="login_con">
                <ul data-v-0f480a62="">
                    <li data-v-0f480a62="">
                        <div data-v-0f480a62="">
                            <div>
                                <span class="address">市中心</span>
                                <span></span>
                            </div>
                            <select>
                                <option value="[object Object]">市中心</option>
                                <option value="[object Object]">淮北矿业分中心</option>
                                <option value="[object Object]">皖北煤电分中心</option>
                            </select>
                        </div>
                    </li>
                    <li data-v-0f480a62="">
                        <input data-v-0f480a62="" placeholder="请输入用户名/身份证/手机号">
                    </li>
                    <li data-v-0f480a62="">
                        <input data-v-0f480a62="" type="password" placeholder="请输入密码">
                    </li>
                </ul>
                <div data-v-0f480a62="" class="submit_button">
                    <button data-v-0f480a62="" @click="submit">登录</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'Home',
    data(){
        return{
            from:{
                name: '',
                password: ''
            }
        }
    },
    methods:{
        submit(){
            
        }
    }
}
</script>
