<template>
    <div class="home">
        <div id="app">
            <div data-v-14d1382d="" class="return_content">
                <div data-v-1da5ee8c="" data-v-14d1382d="" class="line_detail">
                    <div data-v-1da5ee8c="" class="back">
                        <span></span>
                        <span>账户详情</span>
                    </div>
                    <p data-v-1da5ee8c="">*注：查询结果只显示2012年(含)以后的数据，如对查询结果有疑问，请持身份证至公积金中心业务大厅咨询核查！</p>
                    <!---->
                    <table data-v-1da5ee8c="" cellspacing="0">
                        <thead data-v-1da5ee8c="">
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">交易日期</th>
                                <th data-v-1da5ee8c="">借贷标志</th>
                                <th data-v-1da5ee8c="">发生额</th>
                                <th data-v-1da5ee8c="">余额</th>
                                <th data-v-1da5ee8c="">摘要</th>
                            </tr>
                        </thead>
                        <tbody data-v-1da5ee8c="">
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2020-06-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">315.65</th>
                                <th data-v-1da5ee8c="">29005.37</th>
                                <th data-v-1da5ee8c="">年度结息</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2020-06-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">28689.72</th>
                                <th data-v-1da5ee8c="">汇缴202004基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2020-05-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">27441.72</th>
                                <th data-v-1da5ee8c="">汇缴202003基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2020-04-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">26193.72</th>
                                <th data-v-1da5ee8c="">汇缴202002基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2020-03-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">24945.72</th>
                                <th data-v-1da5ee8c="">汇缴202001基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2020-02-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">23697.72</th>
                                <th data-v-1da5ee8c="">汇缴201912基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2020-01-21T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">22449.72</th>
                                <th data-v-1da5ee8c="">汇缴201911基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-12-29T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">21201.72</th>
                                <th data-v-1da5ee8c="">汇缴201910基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-11-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">19953.72</th>
                                <th data-v-1da5ee8c="">汇缴201909基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-10-29T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">18705.72</th>
                                <th data-v-1da5ee8c="">汇缴201908基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-09-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1248</th>
                                <th data-v-1da5ee8c="">17457.72</th>
                                <th data-v-1da5ee8c="">汇缴201907基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-09-23T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c=""></th>
                                <th data-v-1da5ee8c="">16209.72</th>
                                <th data-v-1da5ee8c="">调整个人基数</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-08-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">16209.72</th>
                                <th data-v-1da5ee8c="">汇缴201906基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-07-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">14881.72</th>
                                <th data-v-1da5ee8c="">汇缴201905基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-06-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">508.79</th>
                                <th data-v-1da5ee8c="">13553.72</th>
                                <th data-v-1da5ee8c="">年度结息</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-06-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">13044.93</th>
                                <th data-v-1da5ee8c="">汇缴201904基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-05-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">11716.93</th>
                                <th data-v-1da5ee8c="">汇缴201903基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-04-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">10388.93</th>
                                <th data-v-1da5ee8c="">汇缴201902基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-03-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">9060.93</th>
                                <th data-v-1da5ee8c="">汇缴201901基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-02-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">7732.93</th>
                                <th data-v-1da5ee8c="">汇缴201812基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2019-01-29T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">6404.93</th>
                                <th data-v-1da5ee8c="">汇缴201811基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-12-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">5076.93</th>
                                <th data-v-1da5ee8c="">汇缴201810基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-11-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">3748.93</th>
                                <th data-v-1da5ee8c="">汇缴201809基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-10-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1328</th>
                                <th data-v-1da5ee8c="">2420.93</th>
                                <th data-v-1da5ee8c="">汇缴201808基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-10-23T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c=""></th>
                                <th data-v-1da5ee8c="">1092.93</th>
                                <th data-v-1da5ee8c="">个人封存启封</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-09-25T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c=""></th>
                                <th data-v-1da5ee8c="">1092.93</th>
                                <th data-v-1da5ee8c="">个人封存启封</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-09-10T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c=""></th>
                                <th data-v-1da5ee8c="">1092.93</th>
                                <th data-v-1da5ee8c="">调整个人基数</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-08-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">借</th>
                                <th data-v-1da5ee8c="">173500</th>
                                <th data-v-1da5ee8c="">1092.93</th>
                                <th data-v-1da5ee8c="">部分提取</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-08-29T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">174592.93</th>
                                <th data-v-1da5ee8c="">汇缴201806基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-07-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">173592.93</th>
                                <th data-v-1da5ee8c="">汇缴201805基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-06-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2489.51</th>
                                <th data-v-1da5ee8c="">172592.93</th>
                                <th data-v-1da5ee8c="">年度结息</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-06-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">170103.42</th>
                                <th data-v-1da5ee8c="">汇缴201804基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-05-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">169103.42</th>
                                <th data-v-1da5ee8c="">汇缴201803基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-04-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">168103.42</th>
                                <th data-v-1da5ee8c="">汇缴201802基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-03-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">167103.42</th>
                                <th data-v-1da5ee8c="">汇缴201801基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-02-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">166103.42</th>
                                <th data-v-1da5ee8c="">汇缴201712基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2018-01-29T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">165103.42</th>
                                <th data-v-1da5ee8c="">汇缴201711基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-12-12T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">164103.42</th>
                                <th data-v-1da5ee8c="">汇缴201710基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-11-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">163103.42</th>
                                <th data-v-1da5ee8c="">汇缴201709基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-10-25T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">162103.42</th>
                                <th data-v-1da5ee8c="">汇缴201708基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-09-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1000</th>
                                <th data-v-1da5ee8c="">161103.42</th>
                                <th data-v-1da5ee8c="">汇缴201707基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-08-24T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">160103.42</th>
                                <th data-v-1da5ee8c="">汇缴201706基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-07-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">158731.42</th>
                                <th data-v-1da5ee8c="">汇缴201705基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-06-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2231.37</th>
                                <th data-v-1da5ee8c="">157359.42</th>
                                <th data-v-1da5ee8c="">结息</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-06-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">155128.05</th>
                                <th data-v-1da5ee8c="">汇缴201704基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-05-23T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">153756.05</th>
                                <th data-v-1da5ee8c="">汇缴201703基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-04-25T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">152384.05</th>
                                <th data-v-1da5ee8c="">汇缴201702基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-03-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">151012.05</th>
                                <th data-v-1da5ee8c="">汇缴201701基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-03-08T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">149640.05</th>
                                <th data-v-1da5ee8c="">汇缴201612基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2017-01-19T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">148268.05</th>
                                <th data-v-1da5ee8c="">汇缴201611基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-12-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">146896.05</th>
                                <th data-v-1da5ee8c="">汇缴201610基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-11-10T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">145524.05</th>
                                <th data-v-1da5ee8c="">汇缴201609基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-10-10T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">144152.05</th>
                                <th data-v-1da5ee8c="">汇缴201608基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-09-07T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1372</th>
                                <th data-v-1da5ee8c="">142780.05</th>
                                <th data-v-1da5ee8c="">汇缴201607基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-08-05T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">141408.05</th>
                                <th data-v-1da5ee8c="">汇缴201606基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-07-08T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">139784.05</th>
                                <th data-v-1da5ee8c="">汇缴201605基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-06-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1948.2</th>
                                <th data-v-1da5ee8c="">138160.05</th>
                                <th data-v-1da5ee8c="">结息</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-06-08T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">136211.85</th>
                                <th data-v-1da5ee8c="">汇缴201604基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-05-09T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">134587.85</th>
                                <th data-v-1da5ee8c="">汇缴201603基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-03-09T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">132963.85</th>
                                <th data-v-1da5ee8c="">汇缴201601基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-02-04T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">131339.85</th>
                                <th data-v-1da5ee8c="">汇缴201512基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2016-01-12T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">129715.85</th>
                                <th data-v-1da5ee8c="">汇缴201511基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-12-07T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">128091.85</th>
                                <th data-v-1da5ee8c="">汇缴201510基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-10-31T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">126467.85</th>
                                <th data-v-1da5ee8c="">汇缴201509基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-10-14T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">124843.85</th>
                                <th data-v-1da5ee8c="">补缴</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-10-14T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">123219.85</th>
                                <th data-v-1da5ee8c="">汇缴201508基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-09-09T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">121595.85</th>
                                <th data-v-1da5ee8c="">243191.7</th>
                                <th data-v-1da5ee8c="">系统内转移</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-09-09T00:00:00Z</th>
                                <th data-v-1da5ee8c="">借</th>
                                <th data-v-1da5ee8c="">121595.85</th>
                                <th data-v-1da5ee8c="">121595.85</th>
                                <th data-v-1da5ee8c="">系统内转移</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-08-31T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1624</th>
                                <th data-v-1da5ee8c="">121595.85</th>
                                <th data-v-1da5ee8c="">汇缴201507基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-08-13T00:00:00Z</th>
                                <th data-v-1da5ee8c="">借</th>
                                <th data-v-1da5ee8c="">119971.85</th>
                                <th data-v-1da5ee8c=""></th>
                                <th data-v-1da5ee8c="">系统内转移</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-08-13T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">119971.85</th>
                                <th data-v-1da5ee8c="">119971.85</th>
                                <th data-v-1da5ee8c="">系统内转移</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-08-12T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">119971.85</th>
                                <th data-v-1da5ee8c="">119971.85</th>
                                <th data-v-1da5ee8c="">系统内转移</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-08-12T00:00:00Z</th>
                                <th data-v-1da5ee8c="">借</th>
                                <th data-v-1da5ee8c="">119971.85</th>
                                <th data-v-1da5ee8c=""></th>
                                <th data-v-1da5ee8c="">系统内转移</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-07-21T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">119971.85</th>
                                <th data-v-1da5ee8c="">汇缴201506基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-06-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1552.93</th>
                                <th data-v-1da5ee8c="">118195.85</th>
                                <th data-v-1da5ee8c="">结息</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-06-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">116642.92</th>
                                <th data-v-1da5ee8c="">汇缴201505基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-06-14T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">114866.92</th>
                                <th data-v-1da5ee8c="">汇缴201504基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-05-06T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">113090.92</th>
                                <th data-v-1da5ee8c="">汇缴201503基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-03-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">111314.92</th>
                                <th data-v-1da5ee8c="">汇缴201502基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-03-09T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">109538.92</th>
                                <th data-v-1da5ee8c="">汇缴201501基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2015-01-21T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">107762.92</th>
                                <th data-v-1da5ee8c="">汇缴201412基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-12-23T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">105986.92</th>
                                <th data-v-1da5ee8c="">汇缴201411基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-12-05T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">104210.92</th>
                                <th data-v-1da5ee8c="">汇缴201410基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-10-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">102434.92</th>
                                <th data-v-1da5ee8c="">汇缴201409基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-09-25T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">100658.92</th>
                                <th data-v-1da5ee8c="">汇缴201408基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-08-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1776</th>
                                <th data-v-1da5ee8c="">98882.92</th>
                                <th data-v-1da5ee8c="">汇缴201407基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-07-18T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">97106.92</th>
                                <th data-v-1da5ee8c="">汇缴201406基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-07-09T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">95098.92</th>
                                <th data-v-1da5ee8c="">汇缴201405基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-07-01T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1871.81</th>
                                <th data-v-1da5ee8c="">93090.92</th>
                                <th data-v-1da5ee8c="">结息</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-05-29T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">91219.11</th>
                                <th data-v-1da5ee8c="">汇缴201404基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-04-24T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">89211.11</th>
                                <th data-v-1da5ee8c="">汇缴201403基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-03-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">87203.11</th>
                                <th data-v-1da5ee8c="">汇缴201402基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-02-25T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">85195.11</th>
                                <th data-v-1da5ee8c="">汇缴201401基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2014-01-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">83187.11</th>
                                <th data-v-1da5ee8c="">汇缴201312基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-12-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">81179.11</th>
                                <th data-v-1da5ee8c="">汇缴201311基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-11-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">79171.11</th>
                                <th data-v-1da5ee8c="">汇缴201310基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-10-23T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">77163.11</th>
                                <th data-v-1da5ee8c="">汇缴201309基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-09-29T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">75155.11</th>
                                <th data-v-1da5ee8c="">汇缴201308基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-08-22T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">2008</th>
                                <th data-v-1da5ee8c="">73147.11</th>
                                <th data-v-1da5ee8c="">汇缴201307基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-07-16T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">71139.11</th>
                                <th data-v-1da5ee8c="">汇缴201306基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-07-01T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1314.43</th>
                                <th data-v-1da5ee8c="">69523.11</th>
                                <th data-v-1da5ee8c="">结息</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-06-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">68208.68</th>
                                <th data-v-1da5ee8c="">汇缴201305基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-05-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">66592.68</th>
                                <th data-v-1da5ee8c="">汇缴201304基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-04-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">64976.68</th>
                                <th data-v-1da5ee8c="">汇缴201303基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-03-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">63360.68</th>
                                <th data-v-1da5ee8c="">汇缴201302基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-02-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">61744.68</th>
                                <th data-v-1da5ee8c="">汇缴201301基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2013-01-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">60128.68</th>
                                <th data-v-1da5ee8c="">汇缴201212基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-12-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">58512.68</th>
                                <th data-v-1da5ee8c="">汇缴201211基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-11-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">56896.68</th>
                                <th data-v-1da5ee8c="">汇缴201210基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-10-31T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">55280.68</th>
                                <th data-v-1da5ee8c="">汇缴201209基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-09-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">53664.68</th>
                                <th data-v-1da5ee8c="">汇缴201208基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-08-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1616</th>
                                <th data-v-1da5ee8c="">52048.68</th>
                                <th data-v-1da5ee8c="">汇缴201207基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-07-31T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1804</th>
                                <th data-v-1da5ee8c="">50432.68</th>
                                <th data-v-1da5ee8c="">汇缴201206基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-07-01T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">820.51</th>
                                <th data-v-1da5ee8c="">48628.68</th>
                                <th data-v-1da5ee8c="">结息</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-06-28T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1804</th>
                                <th data-v-1da5ee8c="">47808.17</th>
                                <th data-v-1da5ee8c="">汇缴201205基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-05-29T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1804</th>
                                <th data-v-1da5ee8c="">46004.17</th>
                                <th data-v-1da5ee8c="">汇缴201204基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-04-26T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1804</th>
                                <th data-v-1da5ee8c="">44200.17</th>
                                <th data-v-1da5ee8c="">汇缴201203基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-03-30T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1804</th>
                                <th data-v-1da5ee8c="">42396.17</th>
                                <th data-v-1da5ee8c="">汇缴201202基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-02-27T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1804</th>
                                <th data-v-1da5ee8c="">40592.17</th>
                                <th data-v-1da5ee8c="">汇缴201201基本公积金</th>
                            </tr>
                            <tr data-v-1da5ee8c="">
                                <th data-v-1da5ee8c="">2012-01-20T00:00:00Z</th>
                                <th data-v-1da5ee8c="">贷</th>
                                <th data-v-1da5ee8c="">1804</th>
                                <th data-v-1da5ee8c="">38788.17</th>
                                <th data-v-1da5ee8c="">汇缴201112基本公积金</th>
                            </tr>
                        </tbody>
                    </table>
                    <!---->
                    <!---->
                </div>
            </div>
        </div>
    </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  }
}
</script>
