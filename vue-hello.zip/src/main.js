import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import "./assets/style.css"
import axios from 'axios'
import vue from 'vue';
import vant from 'vant';
import 'vant/lib/index.css';

vue.use(vant);
Vue.prototype.$http = axios
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
